﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace VCOTLKAPPWeb.Utlilites
{
    public class DataModel
    {
        public int StockNo;
        public string Price;
        public string Brand;
        public string Model;
        public int Year;
        public string Engine;
        public int MaxPower;
        public string BodyStyle;
        public string Transmission;
    }

}