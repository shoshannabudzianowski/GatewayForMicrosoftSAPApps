﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace VCOTLKAPPWeb.Utlilites
{
    public class Class1
    {
    }
}